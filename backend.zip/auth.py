"""Login, session, and profile API. Passwords and session tokens are never stored in plaintext."""
import hashlib
import hmac
import secrets
from datetime import datetime, timedelta, timezone
from fastapi import APIRouter, Depends, HTTPException, Request, Response
from pydantic import BaseModel, Field
from database import get_database
from auth_settings import AUTH_ALLOWED_ORIGINS, AUTH_SESSION_HOURS

router = APIRouter(prefix='/api/auth', tags=['auth'])
COOKIE = 'learn_session'

def now():
    return datetime.now(timezone.utc).replace(tzinfo=None)

def password_hash(password, salt=None):
    salt = salt or secrets.token_hex(16)
    key = hashlib.scrypt(password.encode('utf-8'), salt=bytes.fromhex(salt), n=16384, r=8, p=1, dklen=32)
    return 'scrypt$16384$8$1$' + salt + '$' + key.hex()

def verify_password(password, stored):
    try:
        algorithm, n, r, p, salt, digest = stored.split('$')
        if (algorithm, n, r, p) != ('scrypt', '16384', '8', '1'):
            return False
        return hmac.compare_digest(password_hash(password, salt), stored)
    except (ValueError, TypeError):
        return False

def check_origin(request):
    if request.headers.get('origin') not in AUTH_ALLOWED_ORIGINS:
        raise HTTPException(403, 'მოთხოვნის წყარო დაუშვებელია.')

def digest(token):
    return hashlib.sha256(token.encode('ascii')).hexdigest()

class Login(BaseModel):
    username: str = Field(min_length=1, max_length=100)
    password: str = Field(min_length=1, max_length=256)

class ProfileUpdate(BaseModel):
    display_name: str = Field(min_length=1, max_length=200)

def current_user(request: Request):
    token = request.cookies.get(COOKIE, '')
    if not token or len(token) > 128 or not token.isascii():
        raise HTTPException(401, 'სისტემაში შესვლაა საჭირო.')
    db = get_database()
    try:
        with db.cursor() as c:
            c.execute('SELECT u.id,u.username,u.display_name FROM auth_sessions s JOIN auth_users u ON u.id=s.user_id WHERE s.token_hash=%s AND s.expires_at>%s AND u.is_active=1', (digest(token), now()))
            user = c.fetchone()
        if not user:
            raise HTTPException(401, 'სისტემაში შესვლაა საჭირო.')
        return user
    finally:
        db.close()

@router.post('/login')
def login(data: Login, request: Request, response: Response):
    check_origin(request)
    db = get_database()
    try:
        with db.cursor() as c:
            c.execute('SELECT id,username,display_name,password_hash,is_active,failed_attempts,locked_until FROM auth_users WHERE username=%s FOR UPDATE', (data.username.strip(),))
            user = c.fetchone()
            if not user or not user['is_active']:
                # Equalize work for nonexistent accounts.
                password_hash(data.password, '00000000000000000000000000000000')
                raise HTTPException(401, 'მომხმარებელი ან პაროლი არასწორია.')
            if user['locked_until'] and user['locked_until'] > now():
                raise HTTPException(429, 'ანგარიში დროებით დაბლოკილია. სცადე 15 წუთის შემდეგ.')
            if not verify_password(data.password, user['password_hash']):
                attempts = user['failed_attempts'] + 1
                locked = now() + timedelta(minutes=15) if attempts >= 5 else None
                c.execute('UPDATE auth_users SET failed_attempts=%s,locked_until=%s WHERE id=%s', (0 if locked else attempts, locked, user['id']))
                db.commit()
                raise HTTPException(401, 'მომხმარებელი ან პაროლი არასწორია.')
            c.execute('UPDATE auth_users SET failed_attempts=0,locked_until=NULL WHERE id=%s', (user['id'],))
            c.execute('DELETE FROM auth_sessions WHERE expires_at<=%s', (now(),))
            token = secrets.token_urlsafe(32)
            c.execute('INSERT INTO auth_sessions(token_hash,user_id,expires_at) VALUES(%s,%s,%s)', (digest(token), user['id'], now()+timedelta(hours=AUTH_SESSION_HOURS)))
            db.commit()
        response.set_cookie(COOKIE, token, max_age=AUTH_SESSION_HOURS*3600, httponly=True, secure=True, samesite='strict', path='/')
        response.headers['Cache-Control'] = 'no-store'
        return {k:user[k] for k in ('id','username','display_name')}
    finally:
        db.close()

@router.get('/me')
def profile(response: Response, user=Depends(current_user)):
    response.headers['Cache-Control'] = 'no-store'
    return user

@router.put('/me')
def update_profile(data: ProfileUpdate, request: Request, response: Response, user=Depends(current_user)):
    check_origin(request)
    name = data.display_name.strip()
    if not name:
        raise HTTPException(422, 'მიუთითე სახელი.')
    db = get_database()
    try:
        with db.cursor() as c:
            c.execute('UPDATE auth_users SET display_name=%s WHERE id=%s', (name, user['id']))
        db.commit()
    finally:
        db.close()
    response.headers['Cache-Control'] = 'no-store'
    return {**user, 'display_name': name}

@router.post('/logout')
def logout(request: Request, response: Response):
    check_origin(request)
    token = request.cookies.get(COOKIE, '')
    if token and len(token) <= 128 and token.isascii():
        db = get_database()
        try:
            with db.cursor() as c:
                c.execute('DELETE FROM auth_sessions WHERE token_hash=%s', (digest(token),))
            db.commit()
        finally:
            db.close()
    response.delete_cookie(COOKIE, path='/', secure=True, httponly=True, samesite='strict')
    response.headers['Cache-Control'] = 'no-store'
    return {'ok': True}
