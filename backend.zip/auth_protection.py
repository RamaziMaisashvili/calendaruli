"""Attach session checks to the existing application without editing its routers."""
from fastapi import HTTPException
from fastapi.responses import JSONResponse
from fastapi.concurrency import run_in_threadpool
from fastapi.middleware.cors import CORSMiddleware
from auth import current_user, router
from auth_settings import AUTH_ALLOWED_ORIGINS

# The existing server-rendered pages and the React site can submit forms.
WRITE_ORIGINS = set(AUTH_ALLOWED_ORIGINS) | {'https://api.learn.net.ge'}

def install_auth(app):
    app.include_router(router)

    @app.middleware('http')
    async def require_login(request, call_next):
        path = request.url.path
        if request.method == 'OPTIONS' or path.startswith('/static/') or path in ('/', '/health', '/api/auth/login', '/api/auth/logout', '/api/auth/me'):
            return await call_next(request)
        if request.method not in ('GET', 'HEAD', 'OPTIONS') and request.headers.get('origin') not in WRITE_ORIGINS:
            return JSONResponse({'detail': 'მოთხოვნის წყარო დაუშვებელია.'}, status_code=403)
        try:
            request.state.user = await run_in_threadpool(current_user, request)
        except HTTPException as exc:
            return JSONResponse({'detail': exc.detail}, status_code=exc.status_code)
        return await call_next(request)

    # CORS must be the outer layer, including error responses and preflight.
    app.add_middleware(CORSMiddleware, allow_origins=AUTH_ALLOWED_ORIGINS,
                       allow_credentials=True, allow_methods=['GET','POST','PUT','PATCH','DELETE','OPTIONS'],
                       allow_headers=['Content-Type'])
