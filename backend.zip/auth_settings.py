# React საიტის მისამართი: შეცვალე, თუ სხვა დომენს გამოიყენებ.
AUTH_ALLOWED_ORIGINS = ['https://calendar.learn.net.ge']
AUTH_SESSION_HOURS = 12
