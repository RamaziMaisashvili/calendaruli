"""Run on the server: python create_auth_user.py. No password is passed on the command line."""
from getpass import getpass
from auth import password_hash
from database import get_database

def main():
    username = input('მომხმარებლის სახელი: ').strip()
    name = input('სახელი და გვარი: ').strip()
    if not username or len(username)>100 or not name or len(name)>200:
        raise SystemExit('შეავსე მომხმარებლის სახელი და სახელი/გვარი.')
    password = getpass('პაროლი: ')
    again = getpass('გაიმეორე პაროლი: ')
    if len(password)<12 or len(password)>256 or password != again:
        raise SystemExit('პაროლები უნდა ემთხვეოდეს და შედგებოდეს 12–256 სიმბოლოსგან.')
    db=get_database()
    try:
        with db.cursor() as c:
            c.execute('INSERT INTO auth_users(username,display_name,password_hash) VALUES(%s,%s,%s)', (username,name,password_hash(password)))
        db.commit()
        print('მომხმარებელი შეიქმნა.')
    finally:
        db.close()

if __name__ == '__main__':
    main()
