"""კავშირი learn_api მონაცემთა ბაზასთან."""
import pymysql
from pymysql.cursors import DictCursor

DB_HOST = "localhost"
DB_PORT = 3306
DB_NAME = "learn_api"
DB_USER = "ჩაწერე_მომხმარებელი"
DB_PASSWORD = "ჩაწერე_პაროლი"


def get_database():
    return pymysql.connect(
        host=DB_HOST,
        port=DB_PORT,
        user=DB_USER,
        password=DB_PASSWORD,
        database=DB_NAME,
        charset="utf8mb4",
        cursorclass=DictCursor,
        autocommit=False,
        connect_timeout=10,
    )
