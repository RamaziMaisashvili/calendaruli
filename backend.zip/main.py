from fastapi import FastAPI

app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)

@app.get("/")
def index():
    return {"status": "ok", "message": "FastAPI მუშაობს"}
